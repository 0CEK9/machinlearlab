import os
import time
import random
import numpy as np
import pandas as pd
import psutil
import joblib
import torch

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

def initialize_seeds():
    # Fix all seeds to 42 as per global rules
    random.seed(42)
    np.random.seed(42)
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)

def benchmark_train(clf, xtrain, ytrain):
    # warm up run
    clf.fit(xtrain, ytrain)
    
    durations = []
    pid = os.getpid()
    proc = psutil.Process(pid)
    max_mem = 0
    
    for _ in range(5):
        t0 = time.perf_counter()
        clf.fit(xtrain, ytrain)
        t1 = time.perf_counter()
        durations.append(t1 - t0)
        
        current_mem = proc.memory_info().rss
        if current_mem > max_mem:
            max_mem = current_mem
            
    median_time = np.median(durations)
    return median_time, max_mem

def benchmark_infer(clf, xsample):
    # warm up run
    clf.predict(xsample)
    
    durations = []
    pid = os.getpid()
    proc = psutil.Process(pid)
    max_mem = 0
    
    for _ in range(100):
        t0 = time.perf_counter()
        clf.predict(xsample)
        t1 = time.perf_counter()
        durations.append(t1 - t0)
        
        current_mem = proc.memory_info().rss
        if current_mem > max_mem:
            max_mem = current_mem
            
    median_time = np.median(durations)
    return median_time, max_mem

if __name__ == "__main__":
    initialize_seeds()
    
    # Load and split
    features, labels = load_breast_cancer(return_X_y=True)
    xtrain, xtest, ytrain, ytest = train_test_split(
        features, labels, test_size=0.3, stratify=labels, random_state=42
    )
    
    classifiers = {
        'LogisticRegression': LogisticRegression(max_iter=1000, random_state=42),
        'RandomForest': RandomForestClassifier(n_estimators=100, random_state=42)
    }
    
    out_dir = '../results'
    os.makedirs(out_dir, exist_ok=True)
    
    acc_metrics = []
    cost_metrics = []
    
    for clf_name, clf in classifiers.items():
        # Evaluate accuracy
        clf.fit(xtrain, ytrain)
        preds = clf.predict(xtest)
        acc = accuracy_score(ytest, preds)
        acc_metrics.append({'Model': clf_name, 'Test Accuracy': f"{acc:.4f}"})
        
        # Benchmark train
        t_train, m_train = benchmark_train(clf, xtrain, ytrain)
        
        # Benchmark inference
        single_x = xtest[0:1]
        t_infer, m_infer = benchmark_infer(clf, single_x)
        
        # Export model and get size
        export_path = os.path.join(out_dir, f"{clf_name.lower()}_model.joblib")
        joblib.dump(clf, export_path)
        
        size_b = os.path.getsize(export_path)
        size_kb = size_b / 1024.0
        
        cost_metrics.append({
            'Model': clf_name,
            'Train Time (s)': t_train,
            'Train Mem (MB)': m_train / (1024 ** 2),
            'Inf Time (s)': t_infer,
            'Inf Mem (MB)': m_infer / (1024 ** 2),
            'Size (Bytes)': size_b,
            'Size (KB)': size_kb
        })
        
    # Write outputs
    pd.DataFrame(acc_metrics).to_csv(f"{out_dir}/baseline_accuracy.csv", index=False)
    pd.DataFrame(cost_metrics).to_csv(f"{out_dir}/system_costs.csv", index=False)
    
    print("Done benchmarking.")
