import sys
import pkg_resources

def generate_version_report():
    output_path = '../results/versions.txt'
    req_path = '../../requirements.txt'
    
    with open(output_path, 'w') as out_file:
        out_file.write(f"Python: {sys.version}\n")
        
        with open(req_path, 'r') as reqs:
            for line in reqs:
                if '==' in line:
                    package = line.split('==')[0].strip()
                    try:
                        ver = pkg_resources.get_distribution(package).version
                        out_file.write(f"{package}: {ver}\n")
                    except pkg_resources.DistributionNotFound:
                        out_file.write(f"{package}: NOT FOUND\n")

if __name__ == '__main__':
    generate_version_report()
