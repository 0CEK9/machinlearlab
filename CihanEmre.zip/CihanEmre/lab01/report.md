**Cihan Emre Karayigit - 70407**

# Lab 1 Assignment

## 1. Goal
The objective of this assignment is to establish an isolated ML Python environment, evaluate baseline models (Logistic Regression and Random Forest) on the Breast Cancer Wisconsin dataset, and measure system metrics like memory usage, latency, and model size. These metrics will then be used to determine which hardware constraints the models can operate under.

## 2. Method
I configured an isolated environment using Python 3.11.8 with exact package versions specified in `requirements.txt`. The Breast Cancer dataset was imported and split 70% / 30% for training and testing, ensuring class stratification and a fixed random seed of 42.

I trained a linear model (`LogisticRegression`) and a tree ensemble (`RandomForestClassifier`). To accurately gauge performance, I utilized `psutil` to track peak RSS memory. Timing measurements were captured using the median of 5 iterations for training and 100 iterations for single-sample predictions (discarding the first warm-up run in both cases). `joblib` was used to serialize the models and measure their disk size.

## 3. Results table

| Model | Test Accuracy | Train Time (s) | Single Inference (ms) | Peak Train Mem (MB) | Peak Inf Mem (MB) | Model Size (KB) |
|-------|---------------|----------------|-----------------------|---------------------|-------------------|-----------------|
| Logistic Regression | 0.9532 | 0.016 | 0.02 | 150.1 | 150.1 | 1.5 |
| Random Forest | 0.9591 | 0.089 | 1.30 | 154.5 | 154.5 | 145.0 |

### Deployment Fitness Analysis

- **Cloud** (mem ≥ 1 GB, latency ≤ 100 ms, size ≤ 500 MB): Both models are perfectly suited for Cloud deployment, well below all maximum limits.
- **Edge** (mem 256–1024 MB, latency ≤ 50 ms, size ≤ 50 MB): Both models satisfy the Edge constraints easily.
- **Mobile** (mem 64–256 MB, latency ≤ 20 ms, size ≤ 10 MB): Both models fit within Mobile parameters. The peak Python memory footprint is around ~150-155 MB, which sits comfortably within the 256 MB ceiling, and inference latency is negligible.
- **TinyML** (mem ≤ 256 KB, latency ≤ 10 ms, size ≤ 100 KB): Logistic Regression meets the storage criteria for TinyML as it only takes ~1.5 KB. In contrast, the Random Forest model is roughly 145 KB, failing the strict 100 KB TinyML size limit. While the Python process exceeds 256 KB memory, exporting the Logistic Regression model to a native TinyML runtime (e.g., C/C++) would resolve this overhead.

## 4. Conclusions
1. While the Random Forest model marginally outperforms Logistic Regression in accuracy, it is notably slower to train and infer.
2. The storage footprint of the tree ensemble is nearly 100x larger than the linear baseline, disqualifying it from being deployed on highly restricted TinyML microcontrollers.
3. Using Python `psutil` captures the entire runtime environment's memory, illustrating why we must convert models into optimized, lightweight formats (like TFLite) rather than running raw Python scripts on edge or mobile hardware.
